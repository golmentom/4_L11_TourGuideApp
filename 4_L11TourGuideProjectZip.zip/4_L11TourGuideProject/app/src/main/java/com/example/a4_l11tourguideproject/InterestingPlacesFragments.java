package com.example.a4_l11tourguideproject;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class InterestingPlacesFragments extends Fragment {

    public InterestingPlacesFragments() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.list, container, false);

        ArrayList<ListsData> reports = new ArrayList<ListsData>();
        // initialization  of reports

        reports.add(new ListsData("Monmarte distric", "", "", "", "", "", "Artistic district", R.mipmap.monmarte_districtpng));
        reports.add(new ListsData("Triumphal Arch", "Charles de Gaule place, Paris", "", "", "", "", "One of the symbols of Paris ", R.mipmap.triumphal_archpng));
        reports.add(new ListsData("Eiffel tower", "5 Avenue Anatole, Paris", "9", "30", "23", "30", "Viewpoint", R.mipmap.eiffel_towerpng));
        reports.add(new ListsData("Nothrdame cathedral", "Jean-Paul II place, Paris", "9", "00", "20", "00", "Historic church", R.mipmap.nothrdame_cathedralpng));

        ListsDataAdapter reportsAdapter = new ListsDataAdapter(getActivity(), reports, R.color.interestingPlacesColor);

        ListView reportView = (ListView) rootView.findViewById(R.id.listItem);

        reportView.setAdapter((ListAdapter) reportsAdapter);
        return rootView;
    }
}
