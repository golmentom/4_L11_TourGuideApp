package com.example.a4_l11tourguideproject;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ListsDataAdapter extends ArrayAdapter<ListsData> {
    //Background color declaration
    private int mColorResourceId;

    public ListsDataAdapter(Activity context, ArrayList<ListsData> ListsData, int colorResourceId) {
        //to jest ArrayAdapter Superklasy
        super(context, 0, ListsData);
        mColorResourceId = colorResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

// Get the {@link ListData} object located at this position in the list
        ListsData currentListData = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID nameOfPlace
        TextView nameTextView = (TextView) listItemView.findViewById(R.id.nameOfPlace);
        nameTextView.setText(currentListData.getmName());

        // WPROWADZIC IF Find the TextView in the list_item.xml layout with the ID version_number
        LinearLayout addressLabelLayout = (LinearLayout) listItemView.findViewById(R.id.addressLabel);
        TextView addressTextView = (TextView) listItemView.findViewById(R.id.address);
        if (currentListData.hasAddress()) {
            addressTextView.setText(currentListData.getmAddress());
            addressLabelLayout.setVisibility(View.VISIBLE);
        } else {
            addressLabelLayout.setVisibility(View.GONE);
        }

        TextView openClockTextView = (TextView) listItemView.findViewById(R.id.openClock);
        LinearLayout timeLabelLayout = (LinearLayout) listItemView.findViewById(R.id.timeLabel);

        if (currentListData.hasClock()) {
            openClockTextView.setText(currentListData.getmOpenClock());

            TextView openMinuteTextView = (TextView) listItemView.findViewById(R.id.openMinute);
            openMinuteTextView.setText(currentListData.getmOpenMinute());

            TextView closeClockTextView = (TextView) listItemView.findViewById(R.id.closeClock);
            closeClockTextView.setText(currentListData.getmCloseClock());

            TextView closeMinuteTextView = (TextView) listItemView.findViewById(R.id.closeMinute);
            closeMinuteTextView.setText(currentListData.getmCloseMinute());
            timeLabelLayout.setVisibility(View.VISIBLE);
        } else {
            timeLabelLayout.setVisibility(View.GONE);
        }

        TextView typeTextView = (TextView) listItemView.findViewById(R.id.type);
        typeTextView.setText(currentListData.getmType());

        // Find the ImageView in the list_item.xml layout with the ID version_name
        ImageView imageImageView = (ImageView) listItemView.findViewById(R.id.imageView);

        if (currentListData.hasImage()) {
            imageImageView.setImageResource(currentListData.getmImageResourceID());
            imageImageView.setVisibility(View.VISIBLE);
        } else {
            //W innym przypadku  ukryj ImageView (ustaw Visibility na GONE
            imageImageView.setVisibility(View.GONE);
        }

        //Setting background color for each activity.
        View textContainer = listItemView.findViewById(R.id.text_container);

        int color = ContextCompat.getColor(getContext(), mColorResourceId);

        textContainer.setBackgroundColor(color);

        return listItemView;
    }
}