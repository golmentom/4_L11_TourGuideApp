package com.example.a4_l11tourguideproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Museums extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cathegory);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new MuseumFragments()).commit();
    }
}
