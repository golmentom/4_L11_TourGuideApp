package com.example.a4_l11tourguideproject;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {
    //no. of fragments
    final int PAGE_COUNT = 4;
    private Context mContext;

    // private String tabTitles[]= new String[] {"Important","Museums","Restaurants","Places"};
    public FragmentAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new ImportantInformationFragments();
        } else if (position == 1){
            return new MuseumFragments();
        }else if (position == 2){
            return new RestaurantFragments();
        }else {
            return new InterestingPlacesFragments();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return mContext.getString(R.string.important);
        } else if (position == 1){
            return mContext.getString(R.string.museums);
        }else if (position == 2){
            return mContext.getString(R.string.restaurants);
        }else {
            return mContext.getString(R.string.interesting);
        }
    }
}
