package com.example.a4_l11tourguideproject;

public class ListsData {//Name of the place/museum/restaurant etc.
    private String mName;

    //address of the place with first declaration as an empty string
    private String mAddress = NO_ADDRESS_PROVIDED;
    private static final String NO_ADDRESS_PROVIDED = "";

    //clock open variable with first declaration as an empty string
    private String mOpenClock = NO_CLOCK_PROVIDED;
    private static final String NO_CLOCK_PROVIDED = "";

    //minute open declaration
    private String mOpenMinute;

    //cloce clock declaration
    private String mCloseClock;

    //close minute declaration
    private String mCloseMinute;

    //type of place declaration
    private String mType;

    //Image resource ID whth first value declaration
    private int mImageResourceID = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;

    public ListsData(String name, String address, String openClock, String openMinute, String closeClock, String closeMinute, String type){
        mName = name;
        mAddress = address;
        mOpenClock = openClock;
        mOpenMinute = openMinute;
        mCloseClock = closeClock;
        mCloseMinute = closeMinute;
        mType = type;
    }

    public ListsData(String name, String address, String openClock, String openMinute, String closeClock, String closeMinute, String type, int resourceID){
        mName = name;
        mAddress = address;
        mOpenClock = openClock;
        mOpenMinute = openMinute;
        mCloseClock = closeClock;
        mCloseMinute = closeMinute;
        mType = type;
        mImageResourceID = resourceID;
    }

    //getthers method declaration
    public String getmName(){return mName;}

    public String getmAddress(){return mAddress;}

    public String getmOpenClock(){return mOpenClock;}

    public String getmOpenMinute(){return mOpenMinute;}

    public String getmCloseClock(){return mCloseClock;}

    public String getmCloseMinute(){return mCloseMinute;}

    public String getmType(){return mType;}

    public int getmImageResourceID(){return mImageResourceID;}

    //setters method declaration
    public void setmName(String name){mName = name;}

    public void setmAddress(String address){mAddress = address;}

    public void setmOpenClock(String openClock){mOpenClock = openClock;}

    public void setmOpenMinute(String openMinute){mOpenMinute = openMinute;}

    public void setmCloseClock(String closeClock){mCloseClock = closeClock;}

    public void setmCloseMinute(String closeMinute){mCloseClock =closeMinute;}

    public void setmType(String type){mType = type;}

    public void setmImageResourceID(int resourceID){mImageResourceID = resourceID;}

    public boolean hasImage(){
        return mImageResourceID!= NO_IMAGE_PROVIDED;
    }

    //check if the object has image. hide layout if not
    public boolean hasAddress(){
        return mAddress!=NO_ADDRESS_PROVIDED;
    }

    //check if the object has Open clock. hide layout if not
    public boolean hasClock(){
        return mOpenClock!=NO_CLOCK_PROVIDED;
    }
}
