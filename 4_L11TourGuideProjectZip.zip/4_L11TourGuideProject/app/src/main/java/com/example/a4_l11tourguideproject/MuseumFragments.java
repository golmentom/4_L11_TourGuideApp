package com.example.a4_l11tourguideproject;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MuseumFragments extends Fragment {


    public MuseumFragments() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.list, container, false);

        ArrayList<ListsData> reports = new ArrayList<ListsData>();

        // initialization  of reports
        reports.add(new ListsData("Luwr", "99 rue de Rivoli, Paris", "10", "00", "18", "00", "Museum of Art", R.mipmap.luwr_museumpng));
        reports.add(new ListsData("Museum de Monmarte", "12 rue Cortot Paris", "11", "00", "19", "00", "Painting gallery", R.mipmap.momarte_museum));
        reports.add(new ListsData("Centre Pompidou", "Place Georges Pompidou, Paris", "9", "30", "19", "30", "Museum of modern art", R.mipmap.pompidu_museumpng));
        reports.add(new ListsData("Picasso Museum", "5 rue de Thorigny, Paris", "9", "30", "19", "30", "Art gallery", R.mipmap.picasso_museumpng));
        reports.add(new ListsData("Escape Dali", "11 rue Poulbot, Paris", "10", "00", "18", "00", "Painting gallery", R.mipmap.dali_museumpng));

        ListsDataAdapter reportsAdapter = new ListsDataAdapter(getActivity(), reports, R.color.museumColor);

        ListView reportView = (ListView) rootView.findViewById(R.id.listItem);

        reportView.setAdapter(reportsAdapter);
        return rootView;
    }

}
