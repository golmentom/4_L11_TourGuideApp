package com.example.a4_l11tourguideproject;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RestaurantFragments extends Fragment {

    public RestaurantFragments() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.list, container, false);

        ArrayList<ListsData> reports = new ArrayList<ListsData>();
        // initialization  of reports

        reports.add(new ListsData("La Meduse", "177 quai de Valmy, Paris ", "10", "00", "02", "00", "French cuisine"));
        reports.add(new ListsData("Les Apotres de Pigalle", "2 due Germain Pilon, Paris", "11", "00", "23", "00", "American cuisine"));
        reports.add(new ListsData("Epicure", "112 Rue Du Faubourg Saint-Honore, Paris", "11", "30", "0", "30", "French cuisine"));
        reports.add(new ListsData("Happy Cafe", "214 rue de Rivoli, Paris", "9", "30", "22", "30", "Coffee shop"));
        reports.add(new ListsData("II Etait Un Square", "54 rue Corvisart, Paris", "10", "00", "22", "00", "American cuisine"));

        ListsDataAdapter reportsAdapter = new ListsDataAdapter(getActivity(), reports, R.color.restaurantColor);

        ListView reportView = (ListView) rootView.findViewById(R.id.listItem);

        reportView.setAdapter(reportsAdapter);
        return rootView;
    }

}
